// src/components/Dashboard.jsx
import { LogOut, Loader2, TrendingUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useRunwayData } from '../hooks/useRunwayData';
import RunwayGauge from './RunwayGauge';
import SnapshotPanel from './SnapshotPanel';
import QuickLogForm from './QuickLogForm';
import TransactionLedger from './TransactionLedger';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const {
    loading,
    settings,
    transactions,
    spendableBalance,
    taxVault,
    weeklyBurn,
    runway,
    status,
    addInflux,
    addSpend,
    removeTransaction,
    updateSettings,
  } = useRunwayData();

  const currency = settings.currency || 'GBP';

  return (
    <div className="min-h-dvh">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-white/5 bg-ink-950/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-safe-500/15 text-safe-400">
              <TrendingUp size={17} strokeWidth={2.4} />
            </span>
            <span className="font-display text-base font-semibold text-slate-100">Runway &amp; Smooth</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden text-xs text-slate-500 sm:inline">{user?.email}</span>
            <button
              type="button"
              onClick={logout}
              className="flex items-center gap-1.5 rounded-lg border border-white/5 px-3 py-1.5 text-xs text-slate-400 transition hover:border-white/10 hover:text-slate-200"
            >
              <LogOut size={14} /> Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-8">
        {loading ? (
          <div className="flex items-center justify-center py-32 text-slate-500">
            <Loader2 size={22} className="animate-spin" />
          </div>
        ) : (
          <div className="grid gap-4 lg:grid-cols-5 lg:gap-5">
            {/* Left / hero column */}
            <div className="space-y-4 lg:col-span-3">
              <RunwayGauge runway={runway} status={status} weeklyBurn={weeklyBurn} />
              <SnapshotPanel
                spendableBalance={spendableBalance}
                taxVault={taxVault}
                settings={settings}
                weeklyBurn={weeklyBurn}
                currency={currency}
                onUpdateSettings={updateSettings}
                onAddSpend={addSpend}
              />
              <TransactionLedger
                transactions={transactions}
                currency={currency}
                onRemove={removeTransaction}
              />
            </div>

            {/* Right / action column */}
            <div className="lg:col-span-2">
              <div className="lg:sticky lg:top-20">
                <QuickLogForm
                  defaultTaxRate={settings.defaultTaxRate}
                  currency={currency}
                  onAddInflux={addInflux}
                />
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
