// src/components/RunwayGauge.jsx
import { ShieldCheck, ShieldAlert, TriangleAlert, Infinity as InfinityIcon } from 'lucide-react';
import { formatRunwayText } from '../lib/runway';

const STATUS = {
  critical: {
    color: '#f87171',
    glow: 'rgba(248,113,113,0.25)',
    Icon: TriangleAlert,
    eyebrow: 'Runway critical',
    line: 'Time to bring cash in — your buffer is nearly gone.',
  },
  tight: {
    color: '#fbbf24',
    glow: 'rgba(251,191,36,0.22)',
    Icon: ShieldAlert,
    eyebrow: 'Runway tight',
    line: 'You have breathing room, but keep an eye on the next payout.',
  },
  steady: {
    color: '#4ade80',
    glow: 'rgba(74,222,128,0.22)',
    Icon: ShieldCheck,
    eyebrow: 'Runway steady',
    line: 'You are covered. No financial firefighting needed today.',
  },
  strong: {
    color: '#34d399',
    glow: 'rgba(52,211,153,0.28)',
    Icon: ShieldCheck,
    eyebrow: 'Runway strong',
    line: 'Plenty of cushion. You can plan, not panic.',
  },
};

export default function RunwayGauge({ runway, status, weeklyBurn }) {
  const cfg = STATUS[status] ?? STATUS.steady;
  const { Icon } = cfg;

  // Map runway to a 0–100 arc fill, with 16 weeks treated as a "full" buffer.
  const pct = runway.isInfinite
    ? 0
    : Math.min(100, Math.max(0, (runway.weeksFloat / 16) * 100));

  const noBurn = runway.isInfinite;

  return (
    <section className="rs-rise relative overflow-hidden rounded-3xl border border-white/5 bg-ink-900/70 p-6 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.7)] sm:p-9">
      {/* soft status glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 -top-24 h-48 blur-3xl"
        style={{ background: `radial-gradient(50% 100% at 50% 0%, ${cfg.glow}, transparent 70%)` }}
      />

      <div className="relative flex flex-col items-center text-center">
        <div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em]" style={{ color: cfg.color }}>
          <Icon size={15} strokeWidth={2.4} />
          {cfg.eyebrow}
        </div>

        {/* Gauge */}
        <div className="relative mt-2 w-full max-w-[320px]">
          <svg viewBox="0 0 200 118" className="w-full">
            <path
              d="M 15 100 A 85 85 0 0 1 185 100"
              fill="none"
              stroke="rgba(255,255,255,0.07)"
              strokeWidth="13"
              strokeLinecap="round"
            />
            {!noBurn && (
              <path
                d="M 15 100 A 85 85 0 0 1 185 100"
                fill="none"
                stroke={cfg.color}
                strokeWidth="13"
                strokeLinecap="round"
                pathLength="100"
                strokeDasharray="100"
                strokeDashoffset={100 - pct}
                style={{ transition: 'stroke-dashoffset 0.9s cubic-bezier(0.22,1,0.36,1), stroke 0.4s ease' }}
              />
            )}
          </svg>

          {/* Center readout overlaid on the arc */}
          <div className="absolute inset-0 flex flex-col items-center justify-end pb-1">
            {noBurn ? (
              <>
                <InfinityIcon size={34} className="text-slate-300" strokeWidth={1.6} />
                <span className="mt-1 text-xs text-slate-400">Set a burn rate below</span>
              </>
            ) : (
              <>
                <div className="flex items-baseline gap-2 font-display tnum leading-none">
                  <span className="text-5xl font-semibold sm:text-6xl" style={{ color: cfg.color }}>
                    {runway.weeks}
                  </span>
                  <span className="text-base font-medium text-slate-300">
                    {runway.weeks === 1 ? 'week' : 'weeks'}
                  </span>
                </div>
                <div className="mt-1 text-sm text-slate-400 tnum">
                  + {runway.days} {runway.days === 1 ? 'day' : 'days'}
                </div>
              </>
            )}
          </div>
        </div>

        <h1 className="mt-4 text-sm text-slate-300">
          {noBurn ? (
            'Your runway in weeks & days'
          ) : (
            <>
              You are financially safe for{' '}
              <span className="font-semibold text-slate-100">{formatRunwayText(runway)}</span>
            </>
          )}
        </h1>
        <p className="mt-2 max-w-sm text-sm leading-relaxed text-slate-400">{cfg.line}</p>

        {!noBurn && (
          <div className="mt-4 flex items-center gap-1.5 rounded-full border border-white/5 bg-ink-850/80 px-3 py-1.5 text-xs text-slate-400 tnum">
            <span className="text-slate-500">≈</span>
            {runway.months} {runway.months === 1 ? 'month' : 'months'} of cover
          </div>
        )}
      </div>
    </section>
  );
}
