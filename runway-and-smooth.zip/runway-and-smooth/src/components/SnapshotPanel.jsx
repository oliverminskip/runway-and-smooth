// src/components/SnapshotPanel.jsx
import { useState, useEffect } from 'react';
import { Wallet, Lock, Flame, Check, Pencil, Minus, Loader2 } from 'lucide-react';
import { formatMoney } from '../lib/runway';

export default function SnapshotPanel({
  spendableBalance,
  taxVault,
  settings,
  weeklyBurn,
  currency = 'GBP',
  onUpdateSettings,
  onAddSpend,
}) {
  const [editingBurn, setEditingBurn] = useState(false);
  const [burnAmount, setBurnAmount] = useState(settings.burnAmount || '');
  const [burnPeriod, setBurnPeriod] = useState(settings.burnPeriod || 'weekly');

  const [spendOpen, setSpendOpen] = useState(false);
  const [spendAmount, setSpendAmount] = useState('');
  const [spendNote, setSpendNote] = useState('');
  const [spending, setSpending] = useState(false);

  // Keep local edit fields in sync if settings stream in after mount.
  useEffect(() => {
    if (!editingBurn) {
      setBurnAmount(settings.burnAmount || '');
      setBurnPeriod(settings.burnPeriod || 'weekly');
    }
  }, [settings.burnAmount, settings.burnPeriod, editingBurn]);

  async function saveBurn() {
    await onUpdateSettings({
      burnAmount: Math.max(0, Number(burnAmount) || 0),
      burnPeriod,
    });
    setEditingBurn(false);
  }

  async function saveSpend() {
    const amt = Number(spendAmount) || 0;
    if (amt <= 0) return;
    setSpending(true);
    try {
      await onAddSpend({ amount: amt, note: spendNote });
      setSpendAmount('');
      setSpendNote('');
      setSpendOpen(false);
    } finally {
      setSpending(false);
    }
  }

  const burnLabel =
    settings.burnAmount > 0
      ? `${formatMoney(settings.burnAmount, currency)} / ${settings.burnPeriod === 'monthly' ? 'mo' : 'wk'}`
      : 'Not set';

  return (
    <section className="rs-rise grid grid-cols-1 gap-3 sm:grid-cols-3">
      {/* Net cash */}
      <div className="rounded-2xl border border-safe-500/15 bg-safe-500/[0.06] p-4">
        <div className="mb-2 flex items-center gap-2 text-safe-400">
          <Wallet size={16} />
          <span className="text-xs font-semibold uppercase tracking-wide">Net cash</span>
        </div>
        <div className="tnum text-2xl font-semibold text-slate-50">
          {formatMoney(spendableBalance, currency)}
        </div>
        <p className="mt-1 text-xs text-slate-500">Available to spend</p>
      </div>

      {/* Tax vault */}
      <div className="rounded-2xl border border-vault-500/15 bg-vault-500/[0.06] p-4">
        <div className="mb-2 flex items-center gap-2 text-vault-400">
          <Lock size={15} />
          <span className="text-xs font-semibold uppercase tracking-wide">Tax vault</span>
        </div>
        <div className="tnum text-2xl font-semibold text-slate-50">
          {formatMoney(taxVault, currency)}
        </div>
        <p className="mt-1 text-xs text-slate-500">Locked — don't touch</p>
      </div>

      {/* Burn rate (editable) */}
      <div className="rounded-2xl border border-white/5 bg-ink-850/70 p-4">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-300">
            <Flame size={15} className="text-orange-400" />
            <span className="text-xs font-semibold uppercase tracking-wide">Burn rate</span>
          </div>
          {!editingBurn && (
            <button
              type="button"
              onClick={() => setEditingBurn(true)}
              className="text-slate-500 transition hover:text-slate-200"
              aria-label="Edit burn rate"
            >
              <Pencil size={14} />
            </button>
          )}
        </div>

        {editingBurn ? (
          <div className="space-y-2">
            <div className="relative">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-500">£</span>
              <input
                type="number"
                min="0"
                step="1"
                value={burnAmount}
                onChange={(e) => setBurnAmount(e.target.value)}
                placeholder="0"
                className="tnum w-full rounded-lg border border-white/10 bg-ink-900 py-2 pl-7 pr-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-orange-500/30"
              />
            </div>
            <div className="grid grid-cols-2 gap-1 rounded-lg bg-ink-900 p-1">
              {['weekly', 'monthly'].map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setBurnPeriod(p)}
                  className={`rounded-md py-1.5 text-xs font-medium capitalize transition ${
                    burnPeriod === p ? 'bg-ink-700 text-slate-100' : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={saveBurn}
              className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-slate-100 py-2 text-xs font-semibold text-ink-950 transition hover:bg-white"
            >
              <Check size={14} strokeWidth={2.6} /> Save
            </button>
          </div>
        ) : (
          <>
            <div className="tnum text-2xl font-semibold text-slate-50">{burnLabel}</div>
            <p className="mt-1 text-xs text-slate-500 tnum">
              {weeklyBurn > 0 ? `≈ ${formatMoney(weeklyBurn, currency)}/wk normalised` : 'Set to calculate runway'}
            </p>
          </>
        )}
      </div>

      {/* Spend logger spans full width below the three cards */}
      <div className="sm:col-span-3">
        {spendOpen ? (
          <div className="flex flex-col gap-2 rounded-2xl border border-white/5 bg-ink-850/70 p-3 sm:flex-row sm:items-center">
            <div className="relative sm:w-40">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-500">£</span>
              <input
                type="number"
                min="0"
                step="0.01"
                value={spendAmount}
                onChange={(e) => setSpendAmount(e.target.value)}
                placeholder="Amount"
                className="tnum w-full rounded-lg border border-white/10 bg-ink-900 py-2 pl-7 pr-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-red-500/30"
              />
            </div>
            <input
              type="text"
              value={spendNote}
              onChange={(e) => setSpendNote(e.target.value)}
              placeholder="What was it for?"
              className="flex-1 rounded-lg border border-white/10 bg-ink-900 px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-red-500/30"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={saveSpend}
                disabled={spending}
                className="flex items-center justify-center gap-1.5 rounded-lg bg-slate-100 px-4 py-2 text-xs font-semibold text-ink-950 transition hover:bg-white disabled:opacity-60"
              >
                {spending ? <Loader2 size={14} className="animate-spin" /> : <Minus size={14} strokeWidth={2.6} />}
                Log spend
              </button>
              <button
                type="button"
                onClick={() => setSpendOpen(false)}
                className="rounded-lg px-3 py-2 text-xs text-slate-400 transition hover:text-slate-200"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setSpendOpen(true)}
            className="flex w-full items-center justify-center gap-1.5 rounded-2xl border border-dashed border-white/10 py-2.5 text-xs font-medium text-slate-400 transition hover:border-white/20 hover:text-slate-200"
          >
            <Minus size={14} /> Log spending (draws down your runway)
          </button>
        )}
      </div>
    </section>
  );
}
