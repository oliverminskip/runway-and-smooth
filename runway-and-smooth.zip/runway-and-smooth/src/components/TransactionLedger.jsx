// src/components/TransactionLedger.jsx
import { ArrowDownLeft, ArrowUpRight, Trash2, Receipt } from 'lucide-react';
import { formatMoney } from '../lib/runway';

function formatDate(ms) {
  try {
    return new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'short' }).format(new Date(ms));
  } catch {
    return '';
  }
}

export default function TransactionLedger({ transactions = [], currency = 'GBP', onRemove }) {
  if (transactions.length === 0) {
    return (
      <section className="rs-rise rounded-3xl border border-white/5 bg-ink-900/70 p-8 text-center">
        <div className="mx-auto mb-3 grid h-11 w-11 place-items-center rounded-2xl bg-ink-850 text-slate-500">
          <Receipt size={20} />
        </div>
        <h2 className="text-sm font-semibold text-slate-200">No activity yet</h2>
        <p className="mx-auto mt-1 max-w-xs text-xs text-slate-500">
          Log your first cash influx above and your runway will appear instantly.
        </p>
      </section>
    );
  }

  return (
    <section className="rs-rise overflow-hidden rounded-3xl border border-white/5 bg-ink-900/70">
      <div className="flex items-center justify-between px-5 py-4">
        <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-100">
          <Receipt size={16} className="text-slate-400" /> History
        </h2>
        <span className="text-xs text-slate-500 tnum">{transactions.length} entries</span>
      </div>

      <ul className="divide-y divide-white/5">
        {transactions.map((t) => {
          const isIncome = t.type !== 'spend';
          return (
            <li key={t.id} className="group flex items-center gap-3 px-5 py-3.5 transition hover:bg-white/[0.02]">
              <span
                className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${
                  isIncome ? 'bg-safe-500/12 text-safe-400' : 'bg-red-500/12 text-red-400'
                }`}
              >
                {isIncome ? <ArrowDownLeft size={16} strokeWidth={2.4} /> : <ArrowUpRight size={16} strokeWidth={2.4} />}
              </span>

              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-200">{t.note}</p>
                <p className="text-xs text-slate-500 tnum">
                  {formatDate(t.createdAtMs)}
                  {isIncome && t.taxAmount > 0 && (
                    <span className="text-vault-400/80"> · {formatMoney(t.taxAmount, currency)} to vault</span>
                  )}
                </p>
              </div>

              <div className="text-right">
                <div className={`tnum text-sm font-semibold ${isIncome ? 'text-safe-400' : 'text-red-400'}`}>
                  {isIncome ? '+' : '−'}
                  {formatMoney(isIncome ? t.netAmount : t.amount, currency)}
                </div>
                {isIncome && (
                  <div className="tnum text-[11px] text-slate-600">of {formatMoney(t.gross, currency)} gross</div>
                )}
              </div>

              <button
                type="button"
                onClick={() => onRemove(t.id)}
                className="ml-1 text-slate-700 opacity-0 transition group-hover:opacity-100 hover:text-red-400 focus:opacity-100"
                aria-label="Delete entry"
              >
                <Trash2 size={15} />
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
