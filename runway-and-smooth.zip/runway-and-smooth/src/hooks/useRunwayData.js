// src/hooks/useRunwayData.js
// -----------------------------------------------------------------------------
// Streams the signed-in user's settings + transactions from Firestore in real
// time, derives every balance and the runway, and exposes write actions.
//
// Firestore layout (multi-tenant — each user only ever touches their own tree):
//   users/{uid}/meta/settings          -> { burnAmount, burnPeriod, defaultTaxRate, currency }
//   users/{uid}/transactions/{autoId}  -> income or spend records
// -----------------------------------------------------------------------------

import { useEffect, useMemo, useState } from 'react';
import {
  collection,
  doc,
  addDoc,
  deleteDoc,
  setDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { useAuth } from '../context/AuthContext';
import {
  splitInflux,
  summariseTransactions,
  weeklyBurnRate,
  calculateRunway,
  runwayStatus,
} from '../lib/runway';

const DEFAULT_SETTINGS = {
  burnAmount: 0,
  burnPeriod: 'weekly', // 'weekly' | 'monthly'
  defaultTaxRate: 20,
  currency: 'GBP',
};

export function useRunwayData() {
  const { user } = useAuth();
  const uid = user?.uid;

  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  // --- live subscription to settings -----------------------------------------
  useEffect(() => {
    if (!uid) return;
    const settingsRef = doc(db, 'users', uid, 'meta', 'settings');
    const unsub = onSnapshot(settingsRef, (snap) => {
      setSettings(snap.exists() ? { ...DEFAULT_SETTINGS, ...snap.data() } : DEFAULT_SETTINGS);
    });
    return unsub;
  }, [uid]);

  // --- live subscription to transactions -------------------------------------
  useEffect(() => {
    if (!uid) {
      setTransactions([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const txRef = collection(db, 'users', uid, 'transactions');
    const q = query(txRef, orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const rows = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            ...data,
            // createdAt may be null for the brief moment before the server
            // timestamp resolves on a freshly written doc.
            createdAtMs: data.createdAt?.toMillis?.() ?? Date.now(),
          };
        });
        setTransactions(rows);
        setLoading(false);
      },
      (err) => {
        // eslint-disable-next-line no-console
        console.error('[useRunwayData] transaction stream error:', err);
        setLoading(false);
      }
    );
    return unsub;
  }, [uid]);

  // --- write actions ---------------------------------------------------------

  async function addInflux({ gross, note, taxRate }) {
    if (!uid) throw new Error('Not authenticated');
    const split = splitInflux(gross, taxRate);
    const txRef = collection(db, 'users', uid, 'transactions');
    await addDoc(txRef, {
      type: 'income',
      note: (note || '').trim() || 'Cash influx',
      gross: split.gross,
      taxRate: split.taxRate,
      taxAmount: split.taxAmount,
      netAmount: split.netAmount,
      createdAt: serverTimestamp(),
    });
  }

  async function addSpend({ amount, note }) {
    if (!uid) throw new Error('Not authenticated');
    const value = Math.max(0, Number(amount) || 0);
    const txRef = collection(db, 'users', uid, 'transactions');
    await addDoc(txRef, {
      type: 'spend',
      note: (note || '').trim() || 'Spending',
      amount: value,
      createdAt: serverTimestamp(),
    });
  }

  async function removeTransaction(id) {
    if (!uid) throw new Error('Not authenticated');
    await deleteDoc(doc(db, 'users', uid, 'transactions', id));
  }

  async function updateSettings(partial) {
    if (!uid) throw new Error('Not authenticated');
    const settingsRef = doc(db, 'users', uid, 'meta', 'settings');
    await setDoc(settingsRef, partial, { merge: true });
  }

  // --- derived state (memoised) ----------------------------------------------

  const derived = useMemo(() => {
    const summary = summariseTransactions(transactions);
    const weeklyBurn = weeklyBurnRate(settings.burnAmount, settings.burnPeriod);
    const runway = calculateRunway(summary.spendableBalance, weeklyBurn);
    const status = runwayStatus(runway.weeksFloat);
    return { ...summary, weeklyBurn, runway, status };
  }, [transactions, settings.burnAmount, settings.burnPeriod]);

  return {
    loading,
    settings,
    transactions,
    ...derived,
    addInflux,
    addSpend,
    removeTransaction,
    updateSettings,
  };
}
