// src/components/Login.jsx
import { useState } from 'react';
import { Loader2, TrendingUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const FRIENDLY_ERRORS = {
  'auth/invalid-email': 'That email address looks invalid.',
  'auth/invalid-credential': 'Email or password is incorrect.',
  'auth/wrong-password': 'Email or password is incorrect.',
  'auth/user-not-found': 'No account found for that email.',
  'auth/email-already-in-use': 'An account with that email already exists.',
  'auth/weak-password': 'Use at least 6 characters for your password.',
};

export default function Login() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit() {
    setError('');
    setBusy(true);
    try {
      if (mode === 'login') await login(email, password);
      else await register(email, password);
    } catch (e) {
      setError(FRIENDLY_ERRORS[e.code] || 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-dvh items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm rs-rise">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-safe-500/15 text-safe-400">
            <TrendingUp size={22} strokeWidth={2.4} />
          </div>
          <h1 className="font-display text-2xl font-semibold text-slate-50">Runway &amp; Smooth</h1>
          <p className="mt-1 text-sm text-slate-400">Turn lumpy income into calm, visible runway.</p>
        </div>

        <div className="rounded-3xl border border-white/5 bg-ink-900/70 p-6">
          <div className="mb-5 grid grid-cols-2 gap-1 rounded-xl bg-ink-850 p-1">
            {['login', 'register'].map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => { setMode(m); setError(''); }}
                className={`rounded-lg py-2 text-sm font-medium capitalize transition ${
                  mode === m ? 'bg-ink-700 text-slate-100' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {m === 'login' ? 'Sign in' : 'Create account'}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            <input
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-xl border border-white/5 bg-ink-850 px-4 py-3 text-sm text-slate-100 placeholder:text-slate-600 focus:border-safe-500/50 focus:outline-none focus:ring-2 focus:ring-safe-500/20"
            />
            <input
              type="password"
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
              placeholder="Password"
              className="w-full rounded-xl border border-white/5 bg-ink-850 px-4 py-3 text-sm text-slate-100 placeholder:text-slate-600 focus:border-safe-500/50 focus:outline-none focus:ring-2 focus:ring-safe-500/20"
            />

            {error && <p className="text-xs text-red-400">{error}</p>}

            <button
              type="button"
              onClick={handleSubmit}
              disabled={busy}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-safe-500 py-3 text-sm font-semibold text-ink-950 transition hover:bg-safe-400 disabled:opacity-60"
            >
              {busy && <Loader2 size={16} className="animate-spin" />}
              {mode === 'login' ? 'Sign in' : 'Create account'}
            </button>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-slate-600">
          Manual entry only. No bank logins, no open banking — your data stays minimal.
        </p>
      </div>
    </div>
  );
}
