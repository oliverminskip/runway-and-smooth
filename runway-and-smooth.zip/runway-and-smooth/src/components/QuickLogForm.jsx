// src/components/QuickLogForm.jsx
import { useState } from 'react';
import { Plus, Banknote, Loader2 } from 'lucide-react';
import { splitInflux, formatMoney } from '../lib/runway';

export default function QuickLogForm({ defaultTaxRate = 20, currency = 'GBP', onAddInflux }) {
  const [gross, setGross] = useState('');
  const [note, setNote] = useState('');
  const [taxRate, setTaxRate] = useState(defaultTaxRate);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const grossNum = Number(gross) || 0;
  const preview = splitInflux(grossNum, taxRate);

  async function handleSubmit() {
    setError('');
    if (grossNum <= 0) {
      setError('Enter an amount greater than zero.');
      return;
    }
    setSubmitting(true);
    try {
      await onAddInflux({ gross: grossNum, note, taxRate });
      setGross('');
      setNote('');
      setTaxRate(defaultTaxRate);
    } catch (e) {
      setError('Could not save. Check your connection and try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="rs-rise rounded-3xl border border-white/5 bg-ink-900/70 p-5 sm:p-6">
      <div className="mb-4 flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-xl bg-safe-500/15 text-safe-400">
          <Banknote size={17} />
        </span>
        <div>
          <h2 className="text-sm font-semibold text-slate-100">Log a cash influx</h2>
          <p className="text-xs text-slate-500">Tax is shaved off automatically.</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="relative">
          <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-lg text-slate-500">£</span>
          <input
            type="number"
            inputMode="decimal"
            min="0"
            step="0.01"
            value={gross}
            onChange={(e) => setGross(e.target.value)}
            placeholder="5,000"
            className="tnum w-full rounded-2xl border border-white/5 bg-ink-850 py-3.5 pl-9 pr-4 text-lg text-slate-100 placeholder:text-slate-600 focus:border-safe-500/50 focus:outline-none focus:ring-2 focus:ring-safe-500/20"
          />
        </div>

        <input
          type="text"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="e.g. Client X — website design"
          className="w-full rounded-2xl border border-white/5 bg-ink-850 px-4 py-3 text-sm text-slate-100 placeholder:text-slate-600 focus:border-safe-500/50 focus:outline-none focus:ring-2 focus:ring-safe-500/20"
        />

        {/* Tax slider */}
        <div className="rounded-2xl border border-white/5 bg-ink-850/60 p-4">
          <div className="mb-3 flex items-center justify-between text-sm">
            <span className="text-slate-300">Set aside for tax</span>
            <span className="tnum font-semibold text-vault-400">{taxRate}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="50"
            step="1"
            value={taxRate}
            onChange={(e) => setTaxRate(Number(e.target.value))}
            className="w-full"
            aria-label="Tax deduction percentage"
          />
          <div className="mt-3 grid grid-cols-2 gap-2 text-center">
            <div className="rounded-xl bg-vault-500/10 px-2 py-2">
              <div className="text-[11px] uppercase tracking-wide text-vault-400/80">To tax vault</div>
              <div className="tnum text-sm font-semibold text-vault-400">{formatMoney(preview.taxAmount, currency)}</div>
            </div>
            <div className="rounded-xl bg-safe-500/10 px-2 py-2">
              <div className="text-[11px] uppercase tracking-wide text-safe-400/80">To runway</div>
              <div className="tnum text-sm font-semibold text-safe-400">{formatMoney(preview.netAmount, currency)}</div>
            </div>
          </div>
        </div>

        {error && <p className="text-xs text-red-400">{error}</p>}

        <button
          type="button"
          onClick={handleSubmit}
          disabled={submitting}
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-safe-500 py-3.5 text-sm font-semibold text-ink-950 transition hover:bg-safe-400 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? <Loader2 size={17} className="animate-spin" /> : <Plus size={17} strokeWidth={2.6} />}
          {submitting ? 'Saving…' : 'Add to runway'}
        </button>
      </div>
    </section>
  );
}
